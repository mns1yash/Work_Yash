import cv2
#import numpy as np
import matplotlib.pyplot as plt

#adaptive = np.zeros((500,800,3), np.uint8)

img = cv2.imread('169392.jpg',0)
img = cv2.medianBlur(img,3)

ret,th1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
th2 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_MEAN_C,\
                            cv2.THRESH_BINARY,11,2)
th3 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
                            cv2.THRESH_BINARY,11,2)

titles = ['Original Image','Global Threshold','AD_Threshold Mean','AD_Threshold Gaussian']
images = [img,th1,th2,th3]

for i in range(4):
    plt.subplot(2,2,i+1),plt.imshow(images[i],'gray')
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
    cv2.imshow(titles[i],images[i])
    cv2.waitKey(0)
plt.show()
cv2.destroyAllWindows()

