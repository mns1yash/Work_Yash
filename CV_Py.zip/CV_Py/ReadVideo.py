# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 13:08:08 2020

@author: admin
"""

import cv2
cap = cv2.VideoCapture(0)
cap1 = cv2.VideoCapture(1)
while(1):
    k = cv2.waitKey(1) & 0xFF
    if k == 1: #keyboard input 1
# Capture frame-by-frame
        ret, frame = cap.read()
    
# Our operations on the frame come here
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
# Display the resulting frame
        cv2.imshow('frame',gray)
    elif k == 2: #keyboard input 2
        # Capture frame-by-frame
        ret, frame = cap1.read()
    
# Our operations on the frame come here
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
# Display the resulting frame
        cv2.imshow('frame',gray)
    elif cv2.waitKey(1) & 0xFF == ord('q'):
        break
# When everything done, release the capture
cap.release()
cap1.release()
cv2.destroyAllWindows()