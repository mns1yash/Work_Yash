import cv2
# Load two images
img = cv2.imread('169445.jpg')
Gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
Col = cv2.cvtColor(Gray,cv2.COLOR_GRAY2BGR)

cv2.imshow('Gray',Gray)
cv2.waitKey(0)
cv2.imshow('Col',Col)
cv2.waitKey(0)
cv2.destroyAllWindows()