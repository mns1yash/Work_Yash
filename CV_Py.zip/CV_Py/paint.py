# -*- coding: utf-8 -*-
"""
Created on Sat Feb 29 09:03:33 2020

@author: Dinesh
"""

import numpy as np
import cv2
img = np.zeros((500,800,3), np.uint8)
cv2.namedWindow('image')
drawing = False
mode = True
def n(x): 
    pass

# create trackbars for color change
cv2.createTrackbar('R','image',0,255,n)
cv2.createTrackbar('G','image',0,255,n)
cv2.createTrackbar('B','image',0,255,n)
     
def draw_line(event,x,y,flags,param):
    global ix,iy,drawing,mode
    
    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = False
        ix,iy = x,y
    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing == True:
            if mode == True:
                cv2.line(img,(x,y),(ix,iy),[b,g,r],1)
            else:
                print ('Error')    
    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        if mode == True:
            cv2.line(img,(x,y),(ix,iy),[b,g,r],2)
        else: print ('Error1')
        
#cv2.namedWindow('image')
cv2.setMouseCallback('image', draw_line)
while(1):
    cv2.imshow('image',img)
    k = cv2.waitKey(1) & 0xFF
    if k == 27:
        break
# get current positions of four trackbars
    r = cv2.getTrackbarPos('R','image')
    g = cv2.getTrackbarPos('G','image')
    b = cv2.getTrackbarPos('B','image')

cv2.imwrite('paint.jpg',img)
cv2.destroyAllWindows()