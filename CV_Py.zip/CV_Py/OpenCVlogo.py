# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 08:11:42 2020

@author: admin
"""

import cv2
import numpy as np

img=np.zeros((800,800,3), np.uint8)

img = cv2.rectangle(img,(100,70),(700,630),(255,255,255),3)
'''
pts = np.array([[100,230],[100,550],[400,710],[700,550],[700,230],[400,70]], np.int32)
pts = pts.reshape((-1,1,2))
img = cv2.polylines(img,[pts],True,(255,255,255),5)
'''
img = cv2.ellipse(img,(400,227),(100,100),130,0,280,(0,0,255),50)

img = cv2.ellipse(img,(250,475),(100,100),15,0,280,(0,255),50)

img = cv2.ellipse(img,(550,475),(100,100),-55,0,280,255,50)

font = cv2.FONT_HERSHEY_SIMPLEX
cv2.putText(img,'Dinesh G P',(470,675), font, 1.25,(255,255,0),1,cv2.LINE_AA)

cv2.imshow('logo',img)
cv2.waitKey(0)
cv2.imwrite('OpenCVlogo.jpg',img)
cv2.destroyAllWindows()