# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 09:27:09 2020

@author: Dinesh GP
"""
import cv2
import numpy as np

A = cv2.imread('AP.jpg')
B = cv2.imread('OR.jpg')
rows,cols, ch = A.shape
real = np.hstack((A[:,:int(cols/2)],B[:,int(cols/2):]))

# generate Gaussian pyramid for A
G = A.copy()
gpA = [G]
for i in range(6):
    G = cv2.pyrDown(G)
    gpA.append(G)
# generate Gaussian pyramid for B
G = B.copy()
gpB = [G]
for i in range(6):
    G = cv2.pyrDown(G)
    gpB.append(G)
# generate Laplacian Pyramid for A
lpA = [gpA[5]]
GE = cv2.pyrUp(gpA[5])
L = cv2.subtract(gpA[4],GE)
lpA.append(L)

GE = cv2.pyrUp(gpA[4])
L = cv2.subtract(gpA[3],GE)
lpA.append(L)

GE = cv2.pyrUp(gpA[3])
L = cv2.subtract(gpA[2],GE)
lpA.append(L)

#GE = cv2.pyrUp(gpA[2])
#L = cv2.subtract(gpA[1],GE)
#lpA.append(L)

GE = cv2.pyrUp(gpA[1])
L = cv2.subtract(gpA[0],GE)
lpA.append(L)
    
# generate Laplacian Pyramid for B
lpB = [gpB[5]]
GE = cv2.pyrUp(gpB[5])
L = cv2.subtract(gpB[4],GE)
lpB.append(L)

#GE = cv2.pyrUp(gpA[4])
#L = cv2.subtract(gpA[3],GE)
#lpA.append(L)

GE = cv2.pyrUp(gpA[3])
L = cv2.subtract(gpB[2],GE)
lpB.append(L)

#GE = cv2.pyrUp(gpA[2])
#L = cv2.subtract(gpA[1],GE)
#lpA.append(L)

GE = cv2.pyrUp(gpA[1])
L = cv2.subtract(gpB[0],GE)
lpB.append(L)

# Now add left and right halves of images in each level
LS = []
for la,lb in zip(lpA,lpB):
    rows,cols, ch = la.shape
    ls = np.hstack((la[:,0:int(cols/2)], lb[:,int(cols/2):]))
    LS.append(ls)
# now reconstruct
ls_ = LS[0]
for i in range(2,1):
    ls_ = cv2.pyrUp(ls_)
    ls_ = cv2.add(ls_,LS[i])

#image with direct connecting each half
cv2.imshow('A',ls_)
cv2.waitKey(0)
cv2.imshow('A',real)
cv2.waitKey(0)
#cv2.imwrite('Pyramid_blending2.jpg',ls_)
#cv2.imwrite('Direct_blending.jpg',real)
cv2.destroyAllWindows()