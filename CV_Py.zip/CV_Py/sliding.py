# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 15:32:04 2020

@author: admin
"""
import cv2

cv2.namedWindow('dst',cv2.WINDOW_NORMAL)
img1 = cv2.imread('orange.jpg')
img2 = cv2.imread('pink.jpg')
img3 = cv2.imread('red.jpg')
img4 = cv2.imread('lightgreen.jpg')
img5 = cv2.imread('voilet.jpg')
img6 = cv2.imread('yellow.jpg')

dst = cv2.addWeighted(img1,1,img2,0,0)
dst1 = cv2.addWeighted(img1,0,img2,1,0)
dst2 = cv2.addWeighted(img1,0,img2,0,img3,1)
#dst = cv2.addWeighted(img1,0,img2,0.5,img3,0.5)
#dst = cv2.addWeighted(img1,0,img2,0,img3,1)
#dst = cv2.addWeighted(img1,0,img2,0.5,0.5)
#dst = cv2.addWeighted(img1,0,img2,0.3,0.7)
#dst = cv2.addWeighted(0,img2,0,img3,1)

cv2.imshow('dst',dst)
cv2.waitKey(200)
cv2.imshow('dst',dst1)
cv2.waitKey(200)
cv2.imshow('dst',dst2)
cv2.waitKey(200)
cv2.destroyAllWindows()