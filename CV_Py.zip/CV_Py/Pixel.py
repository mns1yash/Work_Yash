# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 08:57:48 2020

@author: Dinesh
"""

import cv2
import numpy as np
img = cv2.imread('image.jpg')
px = img[100,100]
print (px)
blue = img[100,100,0]
print (blue)
img[100,100] = [157,255,255]
print (img[100,100])
print (blue)
img.item(10,10,2)
