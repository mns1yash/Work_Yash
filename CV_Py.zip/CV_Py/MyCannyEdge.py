# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 09:35:02 2020

@author: Dinesh GP
"""

import cv2
import numpy as np
#import matplotlib.pyplot as plt
def n(x): 
    pass
img = cv2.imread('toy.jpg',0)

Cedges = np.zeros((60,360,3), np.uint8)
cv2.namedWindow('Cedges')

#create trackbars to change Threshold
cv2.createTrackbar('MIN','Cedges',0,255,n)
cv2.createTrackbar('MAX','Cedges',0,255,n)

while(1):
    
#get current positions of trackbars
    Min = cv2.getTrackbarPos('MIN','Cedges')
    Max = cv2.getTrackbarPos('MAX','Cedges')
    
    cv2.imshow('Cedges',Cedges)
    k = cv2.waitKey(1) & 0xFF
    
#Default THRESHOLD BINARY
    if k == ord('b'):
        ret,thresh1 = cv2.threshold(img,Min,Max,cv2.THRESH_BINARY)
        edges = cv2.Canny(thresh1,100,200)
        reimg = cv2.resize(edges,None,fx=0.70, fy=0.70, interpolation = cv2.INTER_CUBIC)
        cv2.imshow('THRESH BINARY',reimg)
#THRESHOLD BINARY INVERSE 
    elif k == ord('B'):
        ret,thresh2 = cv2.threshold(img,Min,Max,cv2.THRESH_BINARY_INV)
        edges = cv2.Canny(thresh2,100,200)
        reimg = cv2.resize(edges,None,fx=0.70, fy=0.70, interpolation = cv2.INTER_CUBIC)
        cv2.imshow('THRESH BINARY INVERSE',reimg)
#THRESHOLD TRUNC
    elif k == ord('T'):
        ret,thresh3 = cv2.threshold(img,Min,Max,cv2.THRESH_TRUNC)
        edges = cv2.Canny(thresh3,100,200)
        reimg = cv2.resize(edges,None,fx=0.70, fy=0.70, interpolation = cv2.INTER_CUBIC)
        cv2.imshow('THRESH TRUNC',reimg)
#THRESHOLD TOZERO
    elif k == ord('z'):
        ret,thresh4 = cv2.threshold(img,Min,Max,cv2.THRESH_TOZERO)
        edges = cv2.Canny(thresh4,100,200)
        reimg = cv2.resize(edges,None,fx=0.70, fy=0.70, interpolation = cv2.INTER_CUBIC)
        cv2.imshow('THRESH TOZERO',reimg)
#THRESHOLD TOZERO INVERSE
    elif k == ord('Z'):
        ret,thresh5 = cv2.threshold(img,Min,Max,cv2.THRESH_TOZERO_INV)
        edges = cv2.Canny(thresh5,100,200)
        reimg = cv2.resize(edges,None,fx=0.70, fy=0.70, interpolation = cv2.INTER_CUBIC)
        cv2.imshow('THRESH TOZERO INVERSE',reimg)

    elif k == 27:
        break
    
#cv2.namedWindow('Cedges')
#plt.subplot(121),plt.imshow(img,cmap = 'gray')
#plt.title('Original Image')
#plt.xticks([]),plt.yticks([])
#plt.subplot(121),plt.imshow(edges,cmap = 'gray')
#plt.title('Binary Threshold')
#plt.xticks([]),plt.yticks([])
#plt.subplot(123),plt.imshow(edges,cmap = 'gray')
#plt.title('Canny Edge Image')
#plt.xticks([]),plt.yticks([])

#plt.show()

cv2.destroyAllWindows()