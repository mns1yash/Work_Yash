# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 10:52:44 2020

@author: admin
"""

import cv2
img = cv2.imread('image.jpg',1)
#cv2.namedWindow('image', cv2.WINDOW_NORMAL)
#cv2.imshow('image',img,)
##cv2.imshow('image1',img,)
#k = cv2.waitKey(0)
#if k == 27: # wait for ESC key to exit
#    cv2.destroyAllWindows()
#elif k == ord('s'): # wait for 's' key to save and exit
#    cv2.imwrite('imagegray.png',img)
#    cv2.destroyAllWindows()

res = cv2.resize(img,None,fx=0.5, fy=0.5, interpolation = cv2.INTER_LINEAR)
cv2.imshow('image',img)
cv2.imshow('image1',res)
cv2.waitKey(0)
cv2.destroyAllWindows()