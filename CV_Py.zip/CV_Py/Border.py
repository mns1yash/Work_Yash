import cv2
import numpy as np
#from matplotlib import pyplot as plt
import matplotlib.pyplot as plt
img=np.zeros((500,800,3), np.uint8)
BLUE = [255,0,0]
RED = [0,0,255]
img1 = cv2.imread('169445.jpg')
replicate = cv2.copyMakeBorder(img1,5,5,5,10,cv2.BORDER_REPLICATE)
#reflect = cv2.copyMakeBorder(img1,10,5,10,10,cv2.BORDER_REFLECT)
#reflect101 = cv2.copyMakeBorder(img1,5,10,10,10,cv2.BORDER_REFLECT_101)
#wrap = cv2.copyMakeBorder(img1,10,10,5,10,cv2.BORDER_WRAP, value=RED)
constant= cv2.copyMakeBorder(img1,10,10,10,10,cv2.BORDER_CONSTANT,value=RED)
plt.subplot(231),plt.imshow(img1,'gray'),plt.title('ORIGINAL')
cv2.imshow('image',img1)
#plt.subplot(232),plt.imshow(replicate,'gray'),plt.title('REPLICATE')
#plt.subplot(233),plt.imshow(reflect,'gray'),plt.title('REFLECT')
#plt.subplot(234),plt.imshow(reflect101,'gray'),plt.title('REFLECT_101')
#plt.subplot(235),plt.imshow(wrap,'gray'),plt.title('WRAP')
plt.subplot(236),plt.imshow(constant,'gray'),plt.title('CONSTANT')
cv2.imshow('image1',constant)
plt.show()  
#cv2.imshow('image',img)
cv2.waitKey(0)
cv2.destroyAllWindows()