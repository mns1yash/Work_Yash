import cv2
import numpy as np

img = cv2.imread('169445.jpg',0)

#ret,thresh = cv2.threshold(img,127,255,0)
#contours,hierarchy = cv2.findContours(thresh, 1, 2)
#cnt = contours[0]
#
#
#img1 = cv2.imread('star2.jpg',0)
img2 = cv2.imread('169392.jpg',0)

ret, thresh = cv2.threshold(img, 127, 255,0)
ret, thresh2 = cv2.threshold(img2, 127, 255,0)
contours,hierarchy = cv2.findContours(thresh, 1, 2)
cnt = contours[0]

contours,hierarchy = cv2.findContours(thresh2,1,2)
cnt2 = contours[0]


ret = cv2.matchShapes(cnt,cnt2,1,0.0)

print (ret)






#M = cv2.moments(cnt)
#
##cx = int((M['m10'])/(M['m00']))
##cy = int((M['m01'])/(M['m00']))
#
#area = cv2.contourArea(cnt)
#
#perimeter = cv2.arcLength(cnt,True)
#
#epsilon = 0.1*cv2.arcLength(cnt,True)
#approx = cv2.approxPolyDP(cnt,epsilon,True)
#
#hull = cv2.convexHull(cnt)
#
#print ('perimeter:', perimeter)
#print ('area:', area)
#print ('epsilon:', approx)
#print ('hull:', hull)


#x,y,w,h = cv2.boundingRect(cnt)
#img = cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
#
#rect = cv2.minAreaRect(cnt)
#box = cv2.boxPoints(rect)
#box = np.int0(box)
#im = cv2.drawContours(img,[box],0,(0,0,255),2)
#
#ellipse = cv2.fitEllipse(cnt)
#im = cv2.ellipse(im,ellipse,(0,255,0),2)

#x,y,w,h = cv2.boundingRect(cnt)
#aspect_ratio = float(w)/h

#area = cv2.contourArea(cnt)
#x,y,w,h = cv2.boundingRect(cnt)
#rect_area = w*h
#extent = float(area)/rect_area

#area = cv2.contourArea(cnt)
#hull = cv2.convexHull(cnt)
#hull_area = cv2.contourArea(hull)
#solidity = float(area)/hull_area

#area = cv2.contourArea(cnt)
#equi_diameter = np.sqrt(4*area/np.pi)

#(x,y),(MA,ma),angle = cv2.fitEllipse(cnt)

#mask = np.zeros(img.shape,np.uint8)
#cv2.drawContours(mask,[cnt],0,255,-1)
#pixelpoints = np.transpose(np.nonzero(mask))
#pixelpoints = cv2.findNonZero(mask)

#min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(img,mask = mask)

#mean_val = cv2.mean(img,mask = mask)

leftmost = tuple(cnt[cnt[:,:,0].argmin()][0])
rightmost = tuple(cnt[cnt[:,:,0].argmax()][0])
topmost = tuple(cnt[cnt[:,:,1].argmin()][0])
bottommost = tuple(cnt[cnt[:,:,1].argmax()][0])

print (cnt)

#cv2.imshow('e',im)
#cv2.waitKey(0)
cv2.destroyAllWindows()
