# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 09:45:15 2020

@author: Administrator
"""

import numpy as np
import matplotlib.pyplot as plt
import json
with open('perf.json')as f:
    perf=json.load(f)
n_results=perf['average resolve']
print(n_results,'results')
hourly_perf_total=np.zeros((310,800,8),np.uint8)
for i in range(n_results):
   print( i, perf['data'][i])
hourly_perf_total[i]=perf['data'][i]
plt.plot(hourly_perf_total)
plt.xticks(np.arange(0,n_results+1,24.0))
plt.ylabel('average total milliseconds')
plt.xlabel('hours since'+perf['meta']['endpoint'])
title='monitor 15702020 past week performance'
plt.title(title)
plt.semilogy()
plt.grid(True)
plt.show()    
