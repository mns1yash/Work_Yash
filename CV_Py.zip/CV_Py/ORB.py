# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 11:04:24 2020

@author: Dinesh GP
"""

import numpy as np
import cv2
from matplotlib import pyplot as plt

img = cv2.imread('pattern.png',0)

# Initiate STAR detector
orb = cv2.ORB()

# find the keypoints with ORB
kp = orb.detect(img,None)

# compute the descriptors with ORB
kp, des = orb.compute(img, kp)

# draw only keypoints location,not size and orientation
img2 = cv2.drawKeypoints(img,kp,color=(0,255,0), flags=0)
#plt.imshow(img2),plt.show()

cv2.imshow('Output',img2)
cv2.waitKey(0)
cv2.destroyAllWindows()