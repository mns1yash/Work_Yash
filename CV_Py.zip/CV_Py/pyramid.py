# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 09:08:47 2020

@author: Dinesh GP
"""
import cv2

img = cv2.imread('OR.jpg')

lower_reso = cv2.pyrDown(img)
higher_reso2 = cv2.pyrUp(lower_reso)

cv2.imshow('LR',lower_reso)
cv2.waitKey(0)
cv2.imshow('HR',higher_reso2)
cv2.waitKey(0)
cv2.destroyAllWindows()